image = new TImage("harvard");

log("Hi from Pathagram!");

image.refresh();